#include "DequeManager.h"

int main()
{
	CDequeManager deque;
	return deque.Run();
}